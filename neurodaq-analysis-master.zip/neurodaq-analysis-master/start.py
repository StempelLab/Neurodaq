import mainWindow as m

global browser

if __name__ == '__main__':
    browser = m.main() 

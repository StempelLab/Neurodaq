# Merge .avi files and convert to .mp4 using avimerge and ffmpeg
# Only converts 1 file to mp4, either the merge.avi or the first .avi on the list if 
# merge==False
# Call from within NeuroDAQ, as it converts the files selected in the 
# directory tree

import os
from console import utils as ndaq

def convert():
    # Read user input
    merge = raw_input('Merge .avi files? (y)es, (n)o: ')
    if merge=='y' or merge=='': 
        merge = True
    else: 
        merge = False
    convert = raw_input('Convert to .mp4? (y)es, (n)o: ')
    if convert=='y' or convert=='':
        convert = True
        bitrate = raw_input('Input bitrate for conversion in Mbps (default: 0.25): ')
        if bitrate=='': 
            bitrate = '0.25M'
        else:
            bitrate = bitrate+'M'
    else:
        convert = False

    # Read file names to be processed
    try:
        index = browser.ui.dirTree.selectedIndexes()
    except IndexError:
        print('Error: no file(s) selected')
        return
    currentFolder = os.path.dirname(str(index[0].model().filePath(index[0])))
    fileList = []
    for i in index:
        currentFile = str(i.model().filePath(i))
        ext = os.path.splitext(currentFile)[1]
        if ext=='.avi':
            fileList.append(currentFile)
        else:
            print('Error: no .avi file(s) selected')
            return

    # Merge .avi files
    if merge:
        print('merging:')
        fileList.sort()
        for f in fileList: print(f)
        aviFileout = os.path.splitext(fileList[0])[0]+'_merge.avi'
        cmd = 'avimerge -i '+' '.join(fileList)+' -o '+aviFileout
        os.popen(cmd).read()

    # Convert to .mp4
    if convert:
        if merge:
          mp4Fileout = os.path.splitext(aviFileout)[0]+'.mp4'
          aviFilein = aviFileout
        else:
          mp4Fileout = os.path.splitext(fileList[0])[0]+'.mp4'
          aviFilein = fileList[0]
        print('converting '+aviFilein)
        cmd = 'ffmpeg -i '+aviFilein+' -b:v '+bitrate+' '+mp4Fileout
        os.popen(cmd).read()

if __name__ == "__main__":
    convert()

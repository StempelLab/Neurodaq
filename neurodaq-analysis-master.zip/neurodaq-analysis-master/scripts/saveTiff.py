""" Save 2D arrays in selected H5 items to 
individual tiff files, using the tifffile module.

'items' is a list of H5 items      
"""

import tifffile

# Set folder and basename
folder = '/home/tiago/Dropbox/Projects/threatFLIGHT/ms/Figures/Figure4/cellStack/'
basename = 'plane_'

# Get items
items = browser.ui.workingDataTree.selectedItems()

# Save individual tiffs
for n in range(len(items)):
    if len(str(n))==1:
        number = '0'+str(n)
    else:
        number = str(n)
    tifffile.imsave(folder+basename+number+'.tif', items[n].data)



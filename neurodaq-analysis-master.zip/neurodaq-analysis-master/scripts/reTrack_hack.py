# re-track movies
# select video item in data browser

# Import modules
import numpy as np
import matplotlib.pylab as plt
import matplotlib.animation as animation
import matplotlib.colors as colors
import matplotlib.cm as colormap
import scipy.ndimage as ndimage
import os.path
import cv2
from moviepy.editor import *
from console import utils as ndaq

# Define exception
class fileError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

# VideoLib functions (hacking previous version for .AVIs)
def getAVIinfo(clip):
    aviProps = []
    aviProps.append(0)
    aviProps.append(0)
    aviProps.append(clip.size[0])
    aviProps.append(clip.size[1])
    aviProps.append(clip.fps)
    aviProps.append(cv2.cv.FOURCC('H','2','6','4'))#cv2.VideoWriter_fourcc('H','2','6','4'))
    aviProps.append(int(clip.duration*clip.fps))
    return aviProps #0-posFrame,1-posRatio,2-fWidth,3-fHeight,4-fps,5-fourcc,6-nFrames

def erode(img, erosion_size):
    erosion_size = 2*erosion_size+1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(erosion_size,erosion_size))
    eroded = cv2.erode(img,kernel,iterations=2)
    return eroded

def dilate(img, dilation_size):
    dilation_size = 2*dilation_size+1
    kernel =  cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(dilation_size,dilation_size))
    dilated = cv2.dilate(img,kernel)
    return dilated

def subtractBg(frame, bg):
    ibg = plt.invert(np.uint8(bg))
    iFrame = plt.invert(np.uint8(frame))
    bgSubFrame = np.int32(iFrame)-np.int32(ibg)
    return bgSubFrame    # returns inverted frame

def applyThreshold(frame, ths):
    frame[frame<ths] = 0
    ret,thsFrame = cv2.threshold(np.uint8(frame), ths, 255, cv2.THRESH_BINARY)
    return thsFrame

def getBg(clip, aviProps, nFrames):
    if nFrames>aviProps[6]: nFrames=aviProps[6]
    frames = np.zeros([aviProps[3],aviProps[2],nFrames])
    #randomFrames = np.random.randint(aviProps[6]/2., aviProps[6], size=nFrames)
    randomFrames = np.array([10500,9750,5150,4200,2200,71200])
    for f in np.arange(0,nFrames):
        frame = clip.get_frame(randomFrames[f]/clip.fps)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        frames[:,:,f] = gray
    return frames.mean(axis=2)

def setThreshold(clip, aviProps, bg, ths, morphDiameter):
    sPlot = [221,222,223,224]
    nFrames = aviProps[6]
    frames = np.random.random_integers(int(nFrames/2), nFrames, 4)
    fig = plt.figure()
    cmap = colormap.gray
    cmap.set_over('r')
    for f in np.arange(0,4):
        frame = clip.get_frame(frames[f]/clip.fps)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        bgSubGray = subtractBg(gray, bg)
        thsGray = applyThreshold(bgSubGray, ths)
        thsGray = erode(thsGray, morphDiameter)
        thsGray = dilate(thsGray, morphDiameter)
        gray[gray==255] = 254
        gray[thsGray==255] = 255
        cOm = ndimage.measurements.center_of_mass(thsGray)
        #if tFrame.sum()/255 < nestThreshold: cOm = nestPosition
        fig.add_subplot(sPlot[f])
        plt.imshow(gray, vmax=254)
        plt.set_cmap(cmap)
        plt.plot(cOm[1],cOm[0], 'o')
    plt.show()
    return ths, morphDiameter

# Get video item
try:
    videoItem = browser.ui.workingDataTree.selectedItems()[0]
    if videoItem.attrs['video']=='False':
        raise fileError('')
except fileError:
    print('Error: selected item is not a video stream')

# Open video and get props
clip = VideoFileClip(browser.currentFolder+'/'+videoItem.attrs['mrl'])
aviProps = getAVIinfo(clip)

# Generate background
nFrames = 6
bgOK = False
print("Generating background with default settings...")
bg = getBg(clip, aviProps, nFrames)
while not bgOK:
  plt.imshow(bg)
  plt.set_cmap('gray')
  plt.show()
  uDecision = raw_input("Background OK? [y]es; [n]o ")
  if uDecision=='y':
      bgOK = True
  else:
      uframes = raw_input("Select number of frames ")
      bg = getBg(clip, aviProps, int(uframes))

# Select threshold
ths = 20
morphDiameter = 8
thsOK = False
print("Generating threshold with default settings...")
ths, morphDiameter = setThreshold(clip, aviProps, bg, ths, morphDiameter)
while not thsOK:
  uDecision = raw_input("Threshold OK? [y]es; [n]o ")
  if uDecision=='y':
      thsOK = True
  else:
      while True:
          try:
              print("Current threshold is", ths)
              uths = int(raw_input("Select new threshold "))
              print("Current diameter is", morphDiameter)
              umorph = int(raw_input("Select new diameter to erode and dilate "))
              break
          except ValueError:
              print("Invalid number, please try again ")
      ths, morphDiameter = setThreshold(clip, aviProps, bg, uths, umorph)

# Track movie
mousePositions = []
for f in np.arange(0,aviProps[6]):
#for f in np.arange(0,100):
    frame = clip.get_frame(f/clip.fps)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    bgSubGray = subtractBg(gray, bg)
    thsGray = applyThreshold(bgSubGray, ths)
    thsGray = erode(thsGray, morphDiameter)
    #thsGray = dilate(thsGray, morphDiameter)
    if (thsGray.sum()==0):
        if f==0:
            curPos = (0,0)
        else:
            curPos = mousePositions[-1]
        mousePositions.append(curPos)
    else:
        cOm = ndimage.measurements.center_of_mass(thsGray)
        mousePositions.append(cOm)
mousePositions = np.array(mousePositions)

# Save data to data tree
ndaq.store_data(mousePositions[:,1], name='X-Vertical')
ndaq.store_data(mousePositions[:,0], name='Y-Horizontal')
